package ch09.sec07.exam02;

public interface RemoteControl {
    // 추상 메서드
    void turnOn();
    void turnOff();
}
