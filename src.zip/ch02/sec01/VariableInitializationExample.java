package ch02.sec01;

public class VariableInitializationExample {
    public static void main(String[] args) {
        int value=0;

        int result = value + 10;

//        System.out.println(result);
        char var1 = 'A';
        char c = 65;
        System.out.println(var1);
        System.out.println(c);
    }
}
