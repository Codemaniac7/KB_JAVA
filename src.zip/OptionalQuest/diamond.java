package OptionalQuest;

public class diamond {
    public static void main(String[] args) {
        System.out.println("    " + "*");
        System.out.println("   " + "***");
        System.out.println("  " + "*****");
        System.out.println(" " + "*******");
        System.out.println("  " + "*****");
        System.out.println("   " + "***");
        System.out.println("    " + "*");
//        for(int i=0; i<7; i++) {
//            if() {
//
//            } else {
//
//            }
//        }
    }
}
