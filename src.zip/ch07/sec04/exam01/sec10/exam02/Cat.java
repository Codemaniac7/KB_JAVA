package ch07.sec04.exam01.sec10.exam02;

public class Cat extends Animal {

    @Override
    public void sound() {

    }
}
