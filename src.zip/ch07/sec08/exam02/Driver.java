package ch07.sec08.exam02;

public class Driver {
    public void drive(Vehicle vehicle) {
        vehicle.run();
    }
}
