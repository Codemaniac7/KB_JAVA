package ch07.sec03.exam01;

public class Phone {
    public String model;
    public String color;

    public Phone() {
        System.out.println("Phone() 생성자 실행");
    }
}
