package ch01.sec09;

public class Hello {
    public static void main(String[] args) {
        System.out.print("Hello, java");
        System.out.println("안녕, 자바!");
    }
}
