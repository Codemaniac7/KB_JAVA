package ch01.sec09;

public class HelloWorld {
}
