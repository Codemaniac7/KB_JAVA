package CLIFramework.Lv3.command;

public interface Command {
    void execute();
}
