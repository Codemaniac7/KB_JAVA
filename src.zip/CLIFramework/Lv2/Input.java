package CLIFramework.Lv2;

import java.util.Scanner;

public class Input {
    static Scanner sc = new Scanner(System.in);

    public static int getInt(String title) {
        System.out.println(title);
        return Integer.parseInt(sc.nextLine());
    }
}
