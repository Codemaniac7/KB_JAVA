package ch06.sec08.exam04;

public class Calculator {

    public int areaRectangle(int square) {
        return square * square;
    }

    public int areaRectangle(int square1, int square2) {
        return square1 * square2;
    }
}
