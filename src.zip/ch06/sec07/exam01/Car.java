package ch06.sec07.exam01;

public class Car {
    String carKind;
    String carColor;
    int carLength;

    public Car(String carKind, String carColor, int carLength) {
        this.carKind = carKind;
        this.carColor = carColor;
        this.carLength = carLength;
    }
}
