package ch13.sec01;

public class Box <T>{
    public T content;
}
