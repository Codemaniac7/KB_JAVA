package ch03.sec12;

public class Rect {
    public static void main(String[] args) {

        int x; // low
        int y; // top
        int z; //height
        x=5;
        y=10;
        z=7;
        double area= (x+y)*z/2.0;
        System.out.println("사다리꼴의 넓이: " +area);
    }
}
