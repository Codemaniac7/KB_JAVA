package ch08.sec10.exam02;

public interface Vehicle {
    void run();
}
