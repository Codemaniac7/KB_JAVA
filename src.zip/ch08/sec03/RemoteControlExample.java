package ch08.sec03;

public class RemoteControlExample {
    public static void main(String[] args) {
        System.out.println("리모컨 최대 볼륨: " + RemoteControl.MAX_VOLUME);
        System.out.println("리모컨 최저 볼륨: " + RemoteControl.MIN_VOLUME);
    }
}
