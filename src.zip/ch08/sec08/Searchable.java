package ch08.sec08;

public interface Searchable {
    void search(String url);
}
