package ch08.sec08;

public interface RemoteControl {
    void turnOn();

    void turnOff();
}
