package ch08.sec11.exam02;

public interface Vehicle {
    void run();
}
